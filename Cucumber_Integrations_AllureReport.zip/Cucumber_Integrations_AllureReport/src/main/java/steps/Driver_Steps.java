package steps;

import actions.GlobalWait;
import framework.Configuration;
import framework.Driver;
import io.cucumber.java.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.qameta.allure.Allure;
import io.qameta.allure.Attachment;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.ByteArrayInputStream;
import java.util.Base64;


public class Driver_Steps {

    WebDriver driver;

    @Before
    public void setUp() throws Exception {
        WebDriverManager.chromedriver().setup();
        DesiredCapabilities cap = new DesiredCapabilities();
        Driver.add(Configuration.get("browser"), cap);
        driver = Driver.current();
        driver.get(Configuration.get("url"));
        driver.manage().window().maximize();
        GlobalWait.setDriver(driver);

    }

    @AfterStep
    public void tearDown(Scenario scenario) {
        byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        String base64Screenshot = Base64.getEncoder().encodeToString(screenshot);

        if (scenario.isFailed()) {
            Allure.addAttachment("Step failed", new ByteArrayInputStream(screenshot));
        }
    }


    public WebDriver getDriver() {
        return driver;
    }
}
