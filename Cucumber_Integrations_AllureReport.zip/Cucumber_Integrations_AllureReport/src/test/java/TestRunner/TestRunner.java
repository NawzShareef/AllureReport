package TestRunner;

import io.qameta.allure.Allure;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/java/features/makemytrip.feature",
        glue = {"steps","actions"},
        plugin = {
                "pretty",
                "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
        }
)
public class TestRunner {

}

